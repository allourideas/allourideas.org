  /* Make the widget scroll down to 'About the Scoring' */
  /*
  $('.question_mark').click(function() {
    $('#render_spot').scrollTo('#explanation');
    return false;
  });

